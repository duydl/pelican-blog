A 404 page
==========
:slug: 404
:lang: en
:status: hidden

A simple 404 page.
