Article with multiple and nested categories
===========================================
:date: 2018-11-04
:category: foo/bar, foo/b#az

This is an article with multiple categories
