title: Parent
tags: atag

Parent article with two sub-articles.
