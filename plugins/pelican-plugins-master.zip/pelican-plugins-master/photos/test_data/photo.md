title: Test photo
gallery: {photo}agallery
image: {photo}agallery/best.jpg

Here is my best photo, again.

![]({photo}agallery/best.jpg).
