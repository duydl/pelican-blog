Title: test generic config tag
Date: 2017-12-03
Authors: A. Person

This post is written by 
{% generic config author %}
if all goes well the blog post author (from settings, not from the post) shows up one line above
