A draft article
###############

:status: draft

This is a draft article, it should live under the /drafts/ folder and not be
listed anywhere else.
