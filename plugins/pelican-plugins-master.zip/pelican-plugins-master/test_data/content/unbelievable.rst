Unbelievable !
##############

:date: 2010-10-15 20:30

Or completely awesome. Depends the needs.

`a root-relative link to markdown-article <|filename|/cat1/markdown-article.md>`_
`a file-relative link to markdown-article <|filename|cat1/markdown-article.md>`_
