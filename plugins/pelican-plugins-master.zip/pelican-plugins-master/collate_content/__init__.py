"""
__init__.py
===========

Edward J. Stronge
(c) 2014

Imports collate_content to facilitate Pelican's plugin loading process.
"""
from .collate_content import *
